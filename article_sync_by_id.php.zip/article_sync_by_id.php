<?php
/*
Plugin Name: Article Sync by article_id
Description: Registers article_id meta for Obsidian synchronization
Version: 1.0
Author: Atsushi H.
*/

add_action('rest_api_init', 'register_article_id_meta');

function register_article_id_meta() {
    register_meta('post', 'article_id', array(
        'type' => 'string',
        'description' => 'Unique identifier for syncing with Obsidian',
        'single' => true,
        'show_in_rest' => true,
    ));
}

add_action('save_post', 'debug_save_post', 10, 3);

function debug_save_post($post_id, $post, $update) {
    $article_id = get_post_meta($post_id, 'article_id', true);
    error_log("Saving post {$post_id}, article_id: {$article_id}");
}